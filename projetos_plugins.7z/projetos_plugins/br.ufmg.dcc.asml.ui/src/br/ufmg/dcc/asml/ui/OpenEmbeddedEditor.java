package br.ufmg.dcc.asml.ui;


public class OpenEmbeddedEditor /*implements IExternalJavaAction */{

/*	@Override
	public void execute(Collection<? extends EObject> selections, Map<String, Object> parameters) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean canExecute(Collection<? extends EObject> selections) {
		// TODO Auto-generated method stub
		return false;
	}

*//*    @Override
    protected Injector getInjector() {
        return  ASMLModelActivator.getInstance().getInjector("org.eclipse.xtext.example.domainmodel.Domainmodel");
    }
*/
}
