/**
 */
package br.ufmg.dcc.asml.aSMLModel;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>View</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see br.ufmg.dcc.asml.aSMLModel.ASMLModelPackage#getView()
 * @model
 * @generated
 */
public interface View extends AbstractComponent
{
} // View
