/**
 */
package br.ufmg.dcc.asml.aSMLModel;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Abstract Name Convetion</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see br.ufmg.dcc.asml.aSMLModel.ASMLModelPackage#getAbstractNameConvetion()
 * @model
 * @generated
 */
public interface AbstractNameConvetion extends EObject
{
} // AbstractNameConvetion
