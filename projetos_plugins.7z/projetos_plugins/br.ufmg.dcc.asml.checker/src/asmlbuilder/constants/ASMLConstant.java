package asmlbuilder.constants;

public class ASMLConstant {
	public  static final String MARKER_TYPE = "br.ufmg.dcc.asml.asmlproblem";

	public static final String BUILDER_ID = "br.ufmg.dcc.asml.checker.asmlBuilder";

}
