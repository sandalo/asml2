package <%package%>;

import <%package_componente_base%>.<%componente_base%>BaseRN;

public class <%componente%>RN extends <%componente_base%>BaseRN {

}
