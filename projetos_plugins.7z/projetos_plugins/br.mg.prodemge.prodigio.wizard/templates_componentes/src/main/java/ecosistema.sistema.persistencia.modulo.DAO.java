package <%package%>;

import <%package_componente_base%>.<%componente_base%>BaseDAO;

public class <%componente%>DAO extends <%componente_base%>BaseDAO {

}
