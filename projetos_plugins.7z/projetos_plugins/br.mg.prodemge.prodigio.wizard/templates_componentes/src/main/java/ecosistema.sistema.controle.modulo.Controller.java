package <%package%>;

import <%package_componente_base%>.<%componente_base%>BaseCtr;
import <%dependenciaVO%>;

public class <%componente%>Ctr extends <%componente_base%>BaseCtr<<%componente%>VO> {

}