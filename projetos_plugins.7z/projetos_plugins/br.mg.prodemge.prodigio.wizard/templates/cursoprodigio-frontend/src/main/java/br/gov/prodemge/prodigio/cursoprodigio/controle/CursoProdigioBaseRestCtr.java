package br.gov.prodemge.prodigio.cursoprodigio.controle;

import javax.ws.rs.Path;

import br.gov.prodigio.servicoweb.ProRestCtr;

@Path("/")
public class CursoProdigioBaseRestCtr extends ProRestCtr {

}
