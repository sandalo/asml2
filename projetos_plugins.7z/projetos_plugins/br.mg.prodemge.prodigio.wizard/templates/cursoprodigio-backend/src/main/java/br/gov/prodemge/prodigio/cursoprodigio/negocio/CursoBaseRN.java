package br.gov.prodemge.prodigio.cursoprodigio.negocio;

import br.gov.prodigio.negocio.ProRN;

public class CursoBaseRN extends ProRN{

}
