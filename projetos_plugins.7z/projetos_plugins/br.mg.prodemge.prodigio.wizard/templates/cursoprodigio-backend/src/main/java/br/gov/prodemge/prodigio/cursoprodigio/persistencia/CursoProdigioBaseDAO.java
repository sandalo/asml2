package br.gov.prodemge.prodigio.cursoprodigio.persistencia;

import br.gov.prodigio.persistencia.ProBaseDAO;

public class CursoProdigioBaseDAO extends ProBaseDAO {
}
