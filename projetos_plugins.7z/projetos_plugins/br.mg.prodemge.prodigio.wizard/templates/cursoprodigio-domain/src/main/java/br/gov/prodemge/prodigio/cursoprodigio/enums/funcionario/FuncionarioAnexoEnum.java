package br.gov.prodemge.prodigio.cursoprodigio.enums.funcionario;

public enum FuncionarioAnexoEnum {
	OFICIO, NOTA_FISCAL, MEMORANDO, RECIBO;
}
