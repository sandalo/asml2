package br.gov.prodemge.prodigio.cursoprodigio.entidades;
import br.gov.prodigio.entidades.ProVO;

public class CursoProdigioBaseVO extends ProVO{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4357452789580800295L;

}
