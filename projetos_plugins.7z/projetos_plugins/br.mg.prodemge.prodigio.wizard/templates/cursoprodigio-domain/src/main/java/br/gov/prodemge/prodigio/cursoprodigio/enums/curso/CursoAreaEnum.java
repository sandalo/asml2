package br.gov.prodemge.prodigio.cursoprodigio.enums.curso;

public enum CursoAreaEnum {
	HUMANAS, EXATAS 
}
