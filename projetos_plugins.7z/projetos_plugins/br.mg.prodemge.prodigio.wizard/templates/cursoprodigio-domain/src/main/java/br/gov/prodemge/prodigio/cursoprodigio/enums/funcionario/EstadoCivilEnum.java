package br.gov.prodemge.prodigio.cursoprodigio.enums.funcionario;

public enum EstadoCivilEnum {
	CASADO, SOLTEIRO, DIVORCIADO;
}
